/*
 Name: Kamyavalli Mopidevi
 UID: 118131870
 TerpConnect ID: kmopidev
 Honor Pleadge: I pleadge on my honor I have not used any unauthorized 
 assistance on this Project
 */

const http = require('http');
const express = require("express");
const portNumber = 5000;
const app = express();
const fs = require('fs')
const path = require('path');
const bodyParser = require("body-parser");

class Item{
    #itemsTotal;

    constructor(json){
       this.#itemsTotal = json.itemsList;
    }

    get(){
        return [...this.#itemsTotal];
    }

    itemTable(){
        let table = "<table border = '1'>\n";
        table += "<tr><th>Item</th><th>Cost</th></tr>\n";
        this.#itemsTotal.forEach(p => table += `<tr><td>${p.name}</td><td>${p.cost.toFixed(2)}</td></tr>\n`);
        table += "</table>\n";
        return table;
    }

    itemOption(){
        let option = "";
        this.#itemsTotal.forEach(i=>option+=`<option value="${i.name}">${i.name}</option>`);
        return option;
    }
}

if(process.argv.length !== 3){
    process.stdout.write("Usage supermarketServer.js jsonFile");
    process.exit(1);
}
const jsonFile = process.argv[2];
const data = fs.readFileSync(jsonFile, 'utf-8');
const  values = JSON.parse(data);
const classItems = new Item(values);

app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs'); 
app.use(bodyParser.urlencoded({extended: false}));

app.get('/', (req, res)=>{
    res.render("index");
});

app.get("/catalog", (req, res)=>{
    const output = {itemsTable: classItems.itemTable()};
    res.render("displayItems", output);
});

app.get("/order", (req, res)=>{  
    const output = {items: classItems.itemOption()};
    res.render("placeOrder", output);
});

app.post("/order", (req, res)=>{
    let box = [].concat(req.body.itemsSelected);
    let items =classItems.get().filter(p=>box.includes(p.name));   
    let sum = items.reduce((acc, p)=>acc+p.cost, 0);
    let table = `
    <table border = '1'>
        <tr>
            <th>Items</th>
            <th>Cost</th>
        </tr>
            ${items.map(p=>`
               <tr>
                    <th>${p.name}</td>
                    <th>${(p.cost!== undefined ? p.cost.toFixed(2): "N/A")}</td>
                </tr>`).join('')}
        <tr>
                <td>Total Cost</td>
                <td>${String(sum).replace('.00', '')}</td>
        </tr>
    </table>`;

    const result = {name:req.body.name, 
                    email: req.body.email, 
                    delivery: req.body.delivery, 
                    orderTable: table
                    };
    res.render("OrderConfirmation", result);
});

app.listen(portNumber);
console.log(`Web Server started and runningat http://localhost:${portNumber}`);
const prompt = "Type itemsList or stop to shutdown the server: ";
process.stdout.write(prompt);
process.stdin.on('readable', ()=>{
    let inputData = process.stdin.read();
    if(inputData !== null){
        let command = inputData.toString().trim();
        if (command === "stop") {
            process.stdout.write("Shutting down the server\n")
            process.exit(0);
        } else if (command === "itemsList") {
            let data_input = fs.readFileSync(process.argv[2], 'utf8');
            let json = JSON.parse(data_input);
            let itemInstance = new Item(json);
            console.log('Items List:', itemInstance.get());
        } else {
            process.stdout.write(`Invalid command: ${command}\n`);
        }
        process.stdout.write(prompt);
        process.stdin.resume();
    }
});
    
